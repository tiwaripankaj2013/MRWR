import React from 'react';
class DigitalClock extends React.Component{
    state = {time:new Date().toLocaleDateString()};
    componentDidMount(){
        setInterval(()=>{
            this.setState({time:new Date().toLocaleTimeString()})
        },1000)
    }

    render(){
        return(
            <div className="time">
                <br/>
              <h2>The time is : {this.state.time}</h2>
            </div>
        );
    }
}
export default DigitalClock;