import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import CommentDetails from './CommentDetails';
import * as serviceWorker from './serviceWorker';
import faker from 'faker';
import ApprovalCard from './ApprovalCard.js';

ReactDOM.render(
  <React.StrictMode>
    <div className="ui container comments">
      <ApprovalCard>
        <CommentDetails authorProfile={faker.image.avatar()} author="Rakesh" date="10-10-2020" desc="welcome to new blogs post during the props"/>
      </ApprovalCard>
      <ApprovalCard>
        <CommentDetails authorProfile={faker.image.avatar()} author="Shyam" date="10-05-2020" desc="welcome to latest blogs post during the pandemic"/>
      </ApprovalCard>
      
    </div>
  
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
