import axios from 'axios';
const KEY ='AIzaSyBA6mGtNz_xDEKW8DZzenYgpPhdgFzFWbo';
export default axios.create({
    baseURL : 'https://www.googleapis.com/youtube/v3',
    params:{
        part:'snippet',
        maxResults:5,
        key:KEY,
    }
    
});